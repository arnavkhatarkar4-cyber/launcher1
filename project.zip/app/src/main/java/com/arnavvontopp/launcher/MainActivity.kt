package com.arnavvontopp.launcher

import android.app.Activity
import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.ActivityNotFoundException
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import java.util.Calendar

class MainActivity : Activity() {

    private val profiles = listOf("Arnav", "Sarita", "Aditya")
    private var current: String? = null
    private lateinit var root: FrameLayout
    private var inRecents = false
    private var ramPill: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val ramTick = object : Runnable {
        override fun run() {
            updateRam()
            handler.postDelayed(this, 2000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this)
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(
                Color.parseColor("#2B1B4A"),
                Color.parseColor("#B04A7A"),
                Color.parseColor("#140C28")
            )
        )
        setContentView(root)
        showProfiles()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // A launcher must never close; Back returns to the profile screen.
        if (inRecents) {
            current?.let { showHome(it) }
        } else if (current != null) {
            showProfiles()
        }
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ramTick)
    }

    override fun onResume() {
        super.onResume()
        if (inRecents) handler.post(ramTick)
    }

    private fun label(t: String, size: Float, alpha: Int = 255, font: String = "sans-serif-light"): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = size
        tv.setTextColor(Color.argb(alpha, 255, 255, 255))
        tv.typeface = Typeface.create(font, Typeface.NORMAL)
        return tv
    }

    private fun glass(radius: Int): StateListDrawable {
        fun shape(fill: Int, stroke: Int, w: Int): GradientDrawable {
            val g = GradientDrawable()
            g.cornerRadius = dp(radius).toFloat()
            g.setColor(fill)
            g.setStroke(dp(w), stroke)
            return g
        }
        val sl = StateListDrawable()
        sl.addState(
            intArrayOf(android.R.attr.state_focused),
            shape(Color.parseColor("#66FFFFFF"), Color.WHITE, 2)
        )
        sl.addState(
            intArrayOf(),
            shape(Color.parseColor("#33FFFFFF"), Color.parseColor("#55FFFFFF"), 1)
        )
        return sl
    }

    private fun makeFocusable(v: View, radius: Int, onClick: () -> Unit) {
        v.isFocusable = true
        v.isClickable = true
        v.background = glass(radius)
        v.setOnClickListener { onClick() }
        v.setOnFocusChangeListener { view, focused ->
            val s = if (focused) 1.1f else 1f
            view.animate().scaleX(s).scaleY(s).setDuration(150).start()
        }
    }

    // ---------- Who's watching ----------
    private fun showProfiles() {
        inRecents = false
        handler.removeCallbacks(ramTick)
        current = null
        root.removeAllViews()

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.addView(label("Who's watching?", 36f))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER
        row.clipChildren = false
        row.setPadding(0, dp(48), 0, 0)

        for (name in profiles) {
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.gravity = Gravity.CENTER
            card.setPadding(dp(32), dp(32), dp(32), dp(24))
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            lp.setMargins(dp(16), 0, dp(16), 0)
            card.layoutParams = lp

            val circle = label(name.take(1).uppercase(), 44f, 255, "sans-serif-medium")
            circle.gravity = Gravity.CENTER
            circle.layoutParams = LinearLayout.LayoutParams(dp(96), dp(96))
            val oval = GradientDrawable()
            oval.shape = GradientDrawable.OVAL
            oval.setColor(Color.parseColor("#33FFFFFF"))
            circle.background = oval

            val nm = label(name, 18f, 230)
            nm.setPadding(0, dp(16), 0, 0)

            card.addView(circle)
            card.addView(nm)
            makeFocusable(card, 28) { showHome(name) }
            row.addView(card)
        }
        col.addView(row)
        root.addView(
            col,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        col.post { row.getChildAt(0)?.requestFocus() }
    }

    // ---------- Home ----------
    private fun showHome(name: String) {
        inRecents = false
        handler.removeCallbacks(ramTick)
        current = name
        root.removeAllViews()

        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val greet = when {
            h < 12 -> "Good morning"
            h < 17 -> "Good afternoon"
            else -> "Good evening"
        }

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(64), dp(40), dp(64), dp(40))

        col.addView(label("$greet, $name", 20f, 220))

        val clock = TextClock(this)
        clock.format12Hour = "h:mm"
        clock.format24Hour = "H:mm"
        clock.textSize = 110f
        clock.setTextColor(Color.argb(210, 255, 255, 255))
        clock.typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
        col.addView(clock)

        val date = TextClock(this)
        date.format12Hour = "EEEE d MMMM"
        date.format24Hour = "EEEE d MMMM"
        date.textSize = 20f
        date.setTextColor(Color.argb(220, 255, 255, 255))
        col.addView(date)

        val spacer = View(this)
        col.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))

        val strip = LinearLayout(this)
        strip.orientation = LinearLayout.HORIZONTAL
        strip.clipChildren = false
        strip.gravity = Gravity.CENTER_VERTICAL

        val pm = packageManager
        strip.addView(
            tile(getDrawable(android.R.drawable.ic_menu_recent_history), "Recent") { showRecents() }
        )

        for (ri in loadApps()) {
            val pkg = ri.activityInfo.packageName
            val tile = LinearLayout(this)
            tile.orientation = LinearLayout.VERTICAL
            tile.gravity = Gravity.CENTER
            tile.setPadding(dp(16), dp(16), dp(16), dp(12))
            val lp = LinearLayout.LayoutParams(dp(140), ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.setMargins(dp(10), dp(12), dp(10), dp(12))
            tile.layoutParams = lp

            val icon = ImageView(this)
            icon.setImageDrawable(ri.loadIcon(pm))
            icon.layoutParams = LinearLayout.LayoutParams(dp(72), dp(72))

            val tv = label(ri.loadLabel(pm).toString(), 13f, 230, "sans-serif")
            tv.maxLines = 1
            tv.ellipsize = TextUtils.TruncateAt.END
            tv.gravity = Gravity.CENTER
            tv.setPadding(0, dp(10), 0, 0)

            tile.addView(icon)
            tile.addView(tv)
            makeFocusable(tile, 24) { openApp(pkg) }
            strip.addView(tile)
        }

        val set = LinearLayout(this)
        set.orientation = LinearLayout.VERTICAL
        set.gravity = Gravity.CENTER
        set.setPadding(dp(16), dp(16), dp(16), dp(12))
        val slp = LinearLayout.LayoutParams(dp(140), ViewGroup.LayoutParams.WRAP_CONTENT)
        slp.setMargins(dp(10), dp(12), dp(10), dp(12))
        set.layoutParams = slp
        val sIcon = ImageView(this)
        sIcon.setImageResource(android.R.drawable.ic_menu_preferences)
        sIcon.layoutParams = LinearLayout.LayoutParams(dp(72), dp(72))
        val sTv = label("Settings", 13f, 230, "sans-serif")
        sTv.gravity = Gravity.CENTER
        sTv.setPadding(0, dp(10), 0, 0)
        set.addView(sIcon)
        set.addView(sTv)
        makeFocusable(set, 24) {
            startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        strip.addView(set)

        val scroll = HorizontalScrollView(this)
        scroll.isHorizontalScrollBarEnabled = false
        scroll.clipChildren = false
        scroll.clipToPadding = false
        scroll.setPadding(dp(8), 0, dp(8), 0)
        scroll.addView(strip)
        col.addView(
            scroll,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        root.addView(
            col,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        strip.post { strip.getChildAt(0)?.requestFocus() }
    }

    private fun loadApps(): List<ResolveInfo> {
        val pm = packageManager
        val tv = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0
        )
        val phone = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
        return (tv + phone)
            .distinctBy { it.activityInfo.packageName }
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
    }

    private fun openApp(pkg: String) {
        val i = packageManager.getLeanbackLaunchIntentForPackage(pkg)
            ?: packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) startActivity(i)
    }

    // ---------- Recent apps + RAM ----------
    private fun tile(icon: Drawable?, text: String, onClick: () -> Unit): LinearLayout {
        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL
        t.gravity = Gravity.CENTER
        t.setPadding(dp(16), dp(16), dp(16), dp(12))
        val lp = LinearLayout.LayoutParams(dp(140), ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(10), dp(12), dp(10), dp(12))
        t.layoutParams = lp
        val iv = ImageView(this)
        iv.setImageDrawable(icon)
        iv.layoutParams = LinearLayout.LayoutParams(dp(72), dp(72))
        val tv = label(text, 13f, 230, "sans-serif")
        tv.maxLines = 1
        tv.ellipsize = TextUtils.TruncateAt.END
        tv.gravity = Gravity.CENTER
        tv.setPadding(0, dp(10), 0, 0)
        t.addView(iv)
        t.addView(tv)
        makeFocusable(t, 24, onClick)
        return t
    }

    private fun updateRam() {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val gb = 1024.0 * 1024.0 * 1024.0
        val used = (mi.totalMem - mi.availMem) / gb
        val pct = ((mi.totalMem - mi.availMem) * 100 / mi.totalMem).toInt()
        ramPill?.text = String.format("RAM  %.1f / %.1f GB  \u00B7  %d%%", used, mi.totalMem / gb, pct)
    }

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val mode = ops.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun showRecents() {
        inRecents = true
        root.removeAllViews()

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(64), dp(32), dp(64), dp(40))

        val pill = label("", 16f, 255, "sans-serif-medium")
        pill.setPadding(dp(28), dp(10), dp(28), dp(10))
        val bg = GradientDrawable()
        bg.cornerRadius = dp(40).toFloat()
        bg.setColor(Color.parseColor("#33FFFFFF"))
        bg.setStroke(dp(1), Color.parseColor("#66FFFFFF"))
        pill.background = bg
        ramPill = pill
        val plp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        plp.gravity = Gravity.CENTER_HORIZONTAL
        col.addView(pill, plp)

        val title = label("Recent apps", 32f)
        title.setPadding(0, dp(40), 0, 0)
        col.addView(title)
        col.addView(label("Press and hold OK on an app to close it", 14f, 180))

        val spacer = View(this)
        col.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))

        val strip = LinearLayout(this)
        strip.orientation = LinearLayout.HORIZONTAL
        strip.clipChildren = false
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val pm = packageManager

        if (!hasUsageAccess()) {
            val msg = label(
                "Usage access is needed to list recent apps.\nOpen the button below, or run:\n" +
                    "adb shell appops set $packageName GET_USAGE_STATS allow",
                16f, 230
            )
            msg.gravity = Gravity.CENTER
            col.addView(msg)
            strip.addView(tile(getDrawable(android.R.drawable.ic_menu_preferences), "Allow") {
                try {
                    startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                } catch (e: ActivityNotFoundException) {
                    Toast.makeText(this, "Not available on this TV. Use the adb command.", Toast.LENGTH_LONG).show()
                }
            })
        } else {
            val byPkg = loadApps().associateBy { it.activityInfo.packageName }
            val now = System.currentTimeMillis()
            val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
            val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 24L * 3600L * 1000L, now)
            val recent = (stats ?: emptyList())
                .filter { it.lastTimeUsed > 0 && byPkg.containsKey(it.packageName) }
                .sortedByDescending { it.lastTimeUsed }
                .distinctBy { it.packageName }
                .take(12)

            strip.addView(tile(getDrawable(android.R.drawable.ic_menu_delete), "Clear all") {
                for (u in recent) am.killBackgroundProcesses(u.packageName)
                Toast.makeText(this, "Cleared", Toast.LENGTH_SHORT).show()
                showRecents()
            })
            for (u in recent) {
                val ri = byPkg[u.packageName] ?: continue
                val pkg = u.packageName
                val t = tile(ri.loadIcon(pm), ri.loadLabel(pm).toString()) { openApp(pkg) }
                t.setOnLongClickListener {
                    am.killBackgroundProcesses(pkg)
                    Toast.makeText(this, "Closed", Toast.LENGTH_SHORT).show()
                    showRecents()
                    true
                }
                strip.addView(t)
            }
            if (recent.isEmpty()) {
                col.addView(label("No recent apps yet", 16f, 200))
            }
        }

        val scroll = HorizontalScrollView(this)
        scroll.isHorizontalScrollBarEnabled = false
        scroll.clipChildren = false
        scroll.clipToPadding = false
        scroll.setPadding(dp(8), 0, dp(8), 0)
        scroll.addView(strip)
        col.addView(
            scroll,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        root.addView(
            col,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        handler.removeCallbacks(ramTick)
        handler.post(ramTick)
        strip.post { strip.getChildAt(0)?.requestFocus() }
    }
}
